/*
 * Dallas Baldwin August 18, 2026 */
import java.util.Scanner;
public class Baldwin_Mod_1_3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the amount of water in kilograms: ");
        double waterMass = input.nextDouble();
        System.out.print("Enter the initial temperature in Celsius: ");
        double initialTemperature = input.nextDouble();
        System.out.print("Enter the final temperature in Celsius: ");
        double finalTemperature = input.nextDouble();

        double energy = waterMass
                * (finalTemperature - initialTemperature)
                * 4184;
        System.out.println("The energy needed is " + energy + " Joules.");

        input.close();
    }
}
